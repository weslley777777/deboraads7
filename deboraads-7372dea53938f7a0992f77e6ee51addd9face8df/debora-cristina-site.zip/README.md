# Débora Cristina Estética Avançada — Landing Page

Página de vendas (HTML/CSS puro, sem build) para campanhas no Google Ads e Meta Ads.

## Estrutura
- `index.html` — a página inteira
- `assets/logo.png` — logo

## Publicar no GitHub
```bash
git init
git add .
git commit -m "Landing page Débora Cristina"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/deboracristina.git
git push -u origin main
```

## Publicar online
- **Netlify:** Add new site > Import from Git > escolha o repositório (sem build command; publish directory: `.`)
- **GitHub Pages:** Settings > Pages > Branch `main` / root

## Antes de rodar anúncios
1. Trocar `[inserir nº]` (COREN/CRBM) no `index.html`.
2. Colocar o Pixel da Meta e a tag do Google Ads antes de `</head>`.
3. Nos cliques de WhatsApp, descomentar/adicionar o evento de conversão no `<script>` final (`gtag` / `fbq('track','Lead')`).
